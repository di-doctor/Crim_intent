package com.example.crim_intent

import android.support.v4.app.Fragment


class CrimeFragment : Fragment() {
}